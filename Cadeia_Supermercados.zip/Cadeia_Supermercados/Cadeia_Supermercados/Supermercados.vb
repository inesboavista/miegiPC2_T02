﻿Public Class Supermercados
    Inherits Collections.CollectionBase

    Public Sub Add(ByVal NewSupermercado As Supermercado)
        Me.List.Add(NewSupermercado)
    End Sub

    Public Sub Remove(ByVal oldSupermercado As Supermercado)
        Me.List.Remove(oldSupermercado)
    End Sub

    Default Public Property item(ByVal index As Integer) As Supermercado
        Get
            Return Me.List.Item(index)
        End Get
        Set(ByVal value As Supermercado)
            Me.List.Item(index) = value
        End Set
    End Property

    Public Shadows Sub clear()
        MyBase.Clear()
    End Sub

    Public Shadows Sub RemoveAt(ByVal index As Integer)
        Remove(item(index))
    End Sub
    Public Sub InsertAt(ByVal index As Integer, ByVal NewSupermercado As Supermercado)
        Me.List.Insert(index, NewSupermercado)
    End Sub
End Class
