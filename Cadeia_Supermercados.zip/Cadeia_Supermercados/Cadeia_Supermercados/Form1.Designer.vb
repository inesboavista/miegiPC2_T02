﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TextBoxnome = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBoxcodigo = New System.Windows.Forms.TextBox()
        Me.TextBoxrecocompra = New System.Windows.Forms.TextBox()
        Me.TextBoxprecovenda = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBoxnprodutoscomprados = New System.Windows.Forms.TextBox()
        Me.TextBoxNexempmax = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TextBoxnome
        '
        Me.TextBoxnome.Location = New System.Drawing.Point(174, 62)
        Me.TextBoxnome.Name = "TextBoxnome"
        Me.TextBoxnome.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxnome.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(87, 65)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Nome"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(87, 115)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Codigo"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(87, 156)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Preco compra"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(87, 197)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(69, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Preco Venda"
        '
        'TextBoxcodigo
        '
        Me.TextBoxcodigo.Location = New System.Drawing.Point(174, 112)
        Me.TextBoxcodigo.Name = "TextBoxcodigo"
        Me.TextBoxcodigo.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxcodigo.TabIndex = 5
        '
        'TextBoxrecocompra
        '
        Me.TextBoxrecocompra.Location = New System.Drawing.Point(174, 153)
        Me.TextBoxrecocompra.Name = "TextBoxrecocompra"
        Me.TextBoxrecocompra.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxrecocompra.TabIndex = 6
        '
        'TextBoxprecovenda
        '
        Me.TextBoxprecovenda.Location = New System.Drawing.Point(174, 197)
        Me.TextBoxprecovenda.Name = "TextBoxprecovenda"
        Me.TextBoxprecovenda.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxprecovenda.TabIndex = 7
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(349, 82)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 50)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Criar Produto"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(87, 248)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(117, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "nr Produtos Comprados"
        '
        'TextBoxnprodutoscomprados
        '
        Me.TextBoxnprodutoscomprados.Location = New System.Drawing.Point(210, 245)
        Me.TextBoxnprodutoscomprados.Name = "TextBoxnprodutoscomprados"
        Me.TextBoxnprodutoscomprados.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxnprodutoscomprados.TabIndex = 12
        '
        'TextBoxNexempmax
        '
        Me.TextBoxNexempmax.Location = New System.Drawing.Point(210, 287)
        Me.TextBoxNexempmax.Name = "TextBoxNexempmax"
        Me.TextBoxNexempmax.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxNexempmax.TabIndex = 13
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(87, 287)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(109, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "N exemplares maximo"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(733, 480)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TextBoxNexempmax)
        Me.Controls.Add(Me.TextBoxnprodutoscomprados)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBoxprecovenda)
        Me.Controls.Add(Me.TextBoxrecocompra)
        Me.Controls.Add(Me.TextBoxcodigo)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBoxnome)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBoxnome As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBoxcodigo As TextBox
    Friend WithEvents TextBoxrecocompra As TextBox
    Friend WithEvents TextBoxprecovenda As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBoxnprodutoscomprados As TextBox
    Friend WithEvents TextBoxNexempmax As TextBox
    Friend WithEvents Label7 As Label
End Class
