﻿Public Class Supermercado

    Private _nomesup As String
        Private _morada As String
        Private _listaprod As Produtos

#Region "Constructors"
        Public Sub New()

        End Sub

        Public Sub New(NomeSup As String, Morada As String, ListaProd As Produtos)
            _nomesup = NomeSup
            _morada = Morada
            _listaprod = ListaProd
        End Sub
#End Region

#Region "Properties"
        Public Property Nomesup As String
            Get
                Return _nomesup
            End Get
            Set(value As String)
                _nomesup = value
            End Set
        End Property

        Public Property Morada As String
            Get
                Return _morada
            End Get
            Set(value As String)
                _morada = value
            End Set
        End Property

        Public Property Listaprod As Produtos
            Get
                Return _listaprod
            End Get
            Set(value As Produtos)
                _listaprod = value
            End Set
        End Property
#End Region

#Region "Functions"
        Public Sub Adicionar(Nome As String, Prazo As Date, NumExempMax As Integer, NumExempDisp As Integer,
                       Codigo As String, PrecoForn As Single, PrecoVenda As Single)
            Dim aux As New Produto(Nome, Prazo, NumExempMax, NumExempDisp, Codigo, PrecoForn, PrecoVenda)
            _listaprod.Add(aux)
        End Sub

        Public Sub Remover(nomeprod As String)
            Dim j As Integer = 0
            While j < _listaprod.Count - 1
                If nomeprod = _listaprod(j).Nomeprod Then
                    _listaprod.Remove(_listaprod(j))
                End If
                j = j + 1
            End While
        End Sub

        Public Function Receita(Prod As Produto)
            Dim j As Integer = 0
            Dim soma As Single = 0
            While j < _listaprod.Count - 1
                If Prod.Nomeprod = _listaprod(j).Nomeprod Then
                    Prod.Numexempdisp = Prod.Numexempdisp - 1
                    soma = soma + Prod.Precovenda
                End If
                j = j + 1
            End While
            Return soma
        End Function

        Public Function Lucro_Prejuizo() As Single
            Dim aux As Single

            Return aux
        End Function
#End Region

    End Class
