﻿Public Class Adicionar
    Dim carregamento As Carregamento
    Private Sub Adicionar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        carregamento = New Carregamento(TextBox1.Text.ToString, TextBox2.Text, TextBox3.Text)
    End Sub
End Class