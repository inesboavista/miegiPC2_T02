﻿Public Class Carregamento
    Private _codigo As String
    Private _numero As Integer
    Private _prazoval As Date

    Public Sub New()

    End Sub

    Public Sub New(ByVal codigo As String, ByVal numero As Integer, ByVal prazovalidade As Date)
        _codigo = codigo
        _numero = numero
        _prazoval = prazovalidade
    End Sub

    Public Property Codigo As String
        Get
            Return _codigo
        End Get
        Set(value As String)
            _codigo = value
        End Set
    End Property

    Public Property Numero As Integer
        Get
            Return _numero
        End Get
        Set(value As Integer)
            _numero = value
        End Set
    End Property

    Public Property Prazoval As Date
        Get
            Return _prazoval
        End Get
        Set(value As Date)
            _prazoval = value
        End Set
    End Property
End Class
