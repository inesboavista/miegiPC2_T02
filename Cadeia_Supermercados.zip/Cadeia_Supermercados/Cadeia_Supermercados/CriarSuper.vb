﻿Public Class CriarSuper

    Dim supermercado As Supermercado
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


    End Sub

    Private Sub CriarSuper_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        supermercado = New Supermercado(TextBox1.Text, TextBox2.Text, Capacidade.Text)
    End Sub
End Class