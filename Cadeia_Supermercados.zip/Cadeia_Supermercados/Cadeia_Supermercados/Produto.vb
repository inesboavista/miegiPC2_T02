﻿Public Class Produto
    Private _nomeprod As String
    Private _prazoval As Date
    Private _numexempmax As Integer
    Private _numexempdisp As Integer
    Private _codigo As String
    Private _precoforn As Single
    Private _precovenda As Single

#Region "Constructors"
    Public Sub New(Nome As String, NumExempMax As Integer,
                   Codigo As String, PrecoForn As Single, PrecoVenda As Single)
        _nomeprod = Nome

        _numexempmax = NumExempMax
        _codigo = Codigo
        _precoforn = PrecoForn
        _precovenda = PrecoVenda

    End Sub

    Public Sub New(Nome As String, NumExempMax As Integer, NumExempDisp As Integer,
                   Codigo As String, PrecoForn As Single, PrecoVenda As Single)
        _nomeprod = Nome
        _numexempdisp = NumExempDisp
        _numexempmax = NumExempMax
        _codigo = Codigo
        _precoforn = PrecoForn
        _precovenda = PrecoVenda
    End Sub
#End Region

#Region "Properties"
    Public Property Nomeprod As String
        Get
            Return _nomeprod
        End Get
        Set(value As String)
            _nomeprod = value
        End Set
    End Property

    Public Property Prazoval As Date
        Get
            Return _prazoval
        End Get
        Set(value As Date)
            _prazoval = value
        End Set
    End Property

    Public Property Numexempmax As Integer
        Get
            Return _numexempmax
        End Get
        Set(value As Integer)
            _numexempmax = value
        End Set
    End Property

    Public Property Numexempdisp As Integer
        Get
            Return _numexempdisp
        End Get
        Set(value As Integer)
            _numexempdisp = value
        End Set
    End Property

    Public Property Codigo As String
        Get
            Return _codigo
        End Get
        Set(value As String)
            _codigo = value
        End Set
    End Property

    Public Property Precoforn As Single
        Get
            Return _precoforn
        End Get
        Set(value As Single)
            _precoforn = value
        End Set
    End Property

    Public Property Precovenda As Single
        Get
            Return _precovenda
        End Get
        Set(value As Single)
            _precovenda = value
        End Set
    End Property
#End Region

#Region "Functions"
    Public Function ImprimirSTR() As String
        Return Me.Codigo & vbTab & Me.Nomeprod & vbTab & Me.Prazoval & vbTab & Me.Numexempdisp & vbTab & Me.Numexempmax & vbTab & Me.Precoforn & vbTab & Me.Precovenda
    End Function


    Public Sub AtivarDesconto(Data As Date)
        Dim aux As Integer
        aux = DateDiff(DateInterval.Day, Prazoval, Data)
        If aux <= 3 Then
            Me.Precovenda = Me.Precovenda * 0.5
        ElseIf aux > 3 And aux <= 7 Then
            Me.Precovenda = Me.Precovenda * 0.75
        End If
    End Sub
#End Region

End Class
