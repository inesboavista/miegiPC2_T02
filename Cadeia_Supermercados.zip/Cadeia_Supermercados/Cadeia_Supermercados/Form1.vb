﻿Public Class Form1
    Dim listaprod As Produtos

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim produtocriado As Produto = New Produto(TextBoxnome.Text, TextBoxNexempmax.Text, TextBoxcodigo.Text, TextBoxrecocompra.Text, TextBoxprecovenda.Text)
        listaprod.Add(produtocriado)

    End Sub
End Class
